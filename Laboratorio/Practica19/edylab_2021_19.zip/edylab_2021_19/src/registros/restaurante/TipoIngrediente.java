package registros.restaurante;

public enum TipoIngrediente {
    SOLIDO,
    LIQUIDO
}
