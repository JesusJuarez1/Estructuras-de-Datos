package estructurasnolineales;

/**
 * Enumerado con las opciones de IZQUIERDA y DERECHA
 * @author Jesus
 * @version 1.0
 */
public enum TipoColumna {
    IZQUIERDA,DERECHA
}
