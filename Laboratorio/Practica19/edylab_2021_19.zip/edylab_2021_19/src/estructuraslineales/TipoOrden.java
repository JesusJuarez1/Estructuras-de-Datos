package estructuraslineales;

public enum TipoOrden {ASCENDENTE,DESCENDENTE
}
