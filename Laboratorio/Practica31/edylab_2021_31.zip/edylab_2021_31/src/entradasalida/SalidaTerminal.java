package entradasalida;

public class SalidaTerminal {
    public static void consola(String salida){
        System.out.print(salida);
    }
}
