package pruebas;

import entradasalida.SalidaTerminal;
import herramientas.comunes.Herramientas;
import registros.basedatos.MenuOE;

public class PruebaOE {
    public static void main(String[] args){
        //MenuOE menu = new MenuOE();
        //2458,08/11/2021  09:22:16 p. m.,direct,121,5,4567.3,155
        SalidaTerminal.consola(""+Herramientas.numeroAleaotorio(5,10));
    }
}
