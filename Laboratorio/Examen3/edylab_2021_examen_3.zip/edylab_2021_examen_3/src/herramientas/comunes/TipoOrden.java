package herramientas.comunes;

public enum TipoOrden {ASCENDENTE,DESCENDENTE
}
