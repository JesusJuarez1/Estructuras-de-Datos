package estructurasnolineales;

public enum TipoTabla {
    COLUMNA,
    FILA;
}
