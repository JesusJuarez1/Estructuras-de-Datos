package pruebas;

import entradasalida.SalidaTerminal;
import herramientas.texto.MenuTexto;

public class PruebaBalanceo {
    public static void main(String[] args) {
        MenuTexto.menu();
    }
}
