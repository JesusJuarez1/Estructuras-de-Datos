package herramientas.matematicas;

import estructuraslineales.ArregloDatos;

/**
 * Clase que hace la regresion lineal
 */
public class RegresionLineal { //No terminada
    protected double ALFA = 0.009;

    public RegresionLineal(){
        double p = 0.0;
        double b = 0.0;
        int rep = 0;
        ArregloDatos datos = null;
        while(rep<100000){

        }
    }


}
