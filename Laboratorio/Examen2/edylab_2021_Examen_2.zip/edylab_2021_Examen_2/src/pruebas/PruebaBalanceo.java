package pruebas;

import herramientas.texto.MenuTexto;

public class PruebaBalanceo {
    public static void main(String[] args) {
        MenuTexto.menu();
    }
}
