package estructurasnolineales;

public enum TipoLogaritmo {
    NATURAL,
    BASE10,
    BASE2
}
