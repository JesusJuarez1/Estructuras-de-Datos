package estructurasnolineales;

/**
 * Enumerado con las opciones de SUPERIOR e INFERIOR
 * @author Jesus
 * @version 1.0
 */
public enum TipoRenglon {
    SUPERIOR,INFERIOR
}
