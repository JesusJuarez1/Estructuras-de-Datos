package pruebas;

import registros.calculadora.Calculadora;

public class PruebaCalculadora {
    public static void main(String[] args) {
        Calculadora cal = new Calculadora("(a-2)*y/2^(suma- 9)");
    }
}
