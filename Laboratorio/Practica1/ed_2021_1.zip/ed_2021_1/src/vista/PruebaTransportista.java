package vista;

import controlador.Controlador;
import controlador.EntradaConsola;

public class PruebaTransportista {
    public static void main(String[] args) {
        Controlador.controlador();
    }
}
