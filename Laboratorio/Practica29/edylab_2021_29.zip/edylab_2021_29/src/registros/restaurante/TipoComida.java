package registros.restaurante;

public enum TipoComida {
    VEGETARIANA,
    CARNIVORA,
    VEGANA
}
